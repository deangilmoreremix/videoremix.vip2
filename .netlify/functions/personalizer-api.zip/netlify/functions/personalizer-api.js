var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var personalizer_api_exports = {};
__export(personalizer_api_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(personalizer_api_exports);
var import_supabase_js = require("@supabase/supabase-js");
const supabase = (0, import_supabase_js.createClient)(
  process.env.VITE_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);
const rateLimit = /* @__PURE__ */ new Map();
const RATE_LIMIT = 10;
const WINDOW = 60 * 1e3;
function checkRateLimit(ip) {
  const now = Date.now();
  const userRequests = rateLimit.get(ip) || [];
  const recent = userRequests.filter((t) => now - t < WINDOW);
  if (recent.length >= RATE_LIMIT) return false;
  recent.push(now);
  rateLimit.set(ip, recent);
  return true;
}
async function checkGitHub(username) {
  try {
    const res = await fetch(`https://api.github.com/users/${username}`);
    if (!res.ok) return null;
    const data = await res.json();
    return {
      platform: "github",
      exists: true,
      public_repos: data.public_repos,
      followers: data.followers,
      bio: data.bio,
      company: data.company
    };
  } catch {
    return null;
  }
}
async function runMaigretScan(targetName) {
  const workerUrl = process.env.MAIGRET_WORKER_URL;
  const workerSecret = process.env.MAIGRET_WORKER_SECRET;
  if (workerUrl && workerSecret) {
    try {
      const res = await fetch(`${workerUrl}/scan`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-API-Key": workerSecret
        },
        body: JSON.stringify({ username: targetName })
      });
      if (!res.ok) throw new Error(`Worker returned ${res.status}`);
      const data = await res.json();
      return {
        summary: data.summary || `Public presence suggests activity on ${data.platforms?.length || 0} platforms`,
        platforms: data.platforms || [],
        confidence: data.confidence || 0
      };
    } catch (err) {
      console.error("Maigret worker failed, falling back to GitHub:", err.message);
    }
  }
  const github = await checkGitHub(targetName);
  return {
    summary: github ? `Public presence suggests professional activity on GitHub (${github.public_repos} repos)` : "Public presence suggests professional activity in relevant industry",
    platforms: github ? [github] : [],
    confidence: github ? 0.8 : 0
  };
}
async function handler(event, context) {
  const ip = event.headers["x-forwarded-for"] || "unknown";
  if (!checkRateLimit(ip)) {
    return { statusCode: 429, body: JSON.stringify({ error: "Rate limit exceeded" }) };
  }
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Authorization, Content-Type"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  const path = event.path.replace("/api/personalizer", "");
  const body = event.body ? JSON.parse(event.body) : {};
  try {
    if (path === "/scan" && event.httpMethod === "POST") {
      const { targetName } = body;
      if (!targetName) throw new Error("targetName required");
      const scanData = await runMaigretScan(targetName);
      const { data: scan } = await supabase.from("profile_scan_results").insert({
        user_id: body.userId,
        target_name: targetName,
        scan_data: scanData
      }).select().single();
      return { statusCode: 200, headers, body: JSON.stringify({ scanId: scan.id, scanData }) };
    }
    if (path === "/generate" && event.httpMethod === "POST") {
      const { appId, mode, targetName, targetCompany, manualNotes, offer, goal, tone, cta } = body;
      if (!targetName || !mode) throw new Error("targetName and mode required");
      const output = {
        type: mode,
        content: `Generated ${mode} for ${targetName} at ${targetCompany || "N/A"}. ${manualNotes || ""}`,
        metadata: { tone, offer, goal, cta }
      };
      const { data: project } = await supabase.from("personalization_projects").insert({
        user_id: body.userId,
        app_id: appId,
        mode,
        target_name: targetName,
        target_company: targetCompany,
        manual_notes: manualNotes,
        status: "complete"
      }).select().single();
      await supabase.from("personalization_outputs").insert({
        project_id: project.id,
        output_type: mode,
        content: output
      });
      return { statusCode: 200, headers, body: JSON.stringify({ output, project }) };
    }
    return { statusCode: 404, body: JSON.stringify({ error: "Endpoint not found" }) };
  } catch (err) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: err.message }) };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
